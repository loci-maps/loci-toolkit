from create_embeddings import getAllEmbeddings
from dimensionality_reduction import runReduction

def main():
    getAllEmbeddings()
    runReduction()

if __name__ == "__main__":
    main()